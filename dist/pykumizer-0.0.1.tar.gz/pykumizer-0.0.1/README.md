# pykumizer
 Wrapper for working with the private API of Kaspersky Unified and Analysis Platform 2.1.
# Usage

 
